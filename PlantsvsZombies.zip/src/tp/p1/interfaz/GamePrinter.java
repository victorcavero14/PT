package tp.p1.interfaz;

import tp.p1.Game;

public interface GamePrinter {
	//metodo print Game
	public abstract void printGame (Game game);
	
}
